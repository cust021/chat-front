
export const SignUp = ()=>{
    return (
        <div></div>
    )
}